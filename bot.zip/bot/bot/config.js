const global = {
    owner: [7699437040], // ganti jadi id mu
    botToken: "7832417783:AAGYaYx1OtOg-B99HA6O5zWllZb7oFYFzIE", //isi make token bot mu
}

module.exports = global;